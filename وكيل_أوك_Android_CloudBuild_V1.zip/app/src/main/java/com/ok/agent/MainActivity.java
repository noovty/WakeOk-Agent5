package com.ok.agent;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 LinearLayout box; TextView status;
 public void onCreate(Bundle b){super.onCreate(b); box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(28,40,28,20);
 TextView t=new TextView(this);t.setText("وكيل أوك\\n\\n🎙️ الأوامر الصوتية + التحكم بواتساب");t.setTextSize(24);box.addView(t);
 Button access=new Button(this);access.setText("⚙️ تفعيل صلاحية التحكم بواتساب");access.setOnClickListener(v->startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS")));box.addView(access);
 Button mic=new Button(this);mic.setText("🎙️ أمر صوتي");mic.setOnClickListener(v->startActivity(new Intent("android.speech.action.RECOGNIZE_SPEECH")));box.addView(mic);
 status=new TextView(this);status.setText("\\nالحالة: جاهز");status.setTextSize(18);box.addView(status);setContentView(box);}
}