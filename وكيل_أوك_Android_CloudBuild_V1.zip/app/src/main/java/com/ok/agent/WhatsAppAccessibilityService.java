package com.ok.agent;
import android.accessibilityservice.AccessibilityService; import android.view.accessibility.AccessibilityEvent;
public class WhatsAppAccessibilityService extends AccessibilityService {
 public void onAccessibilityEvent(AccessibilityEvent e){ /* نقطة التحكم الآلي بواجهة واتساب */ }
 public void onInterrupt(){}
}